package com.nucleus.execution;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nucleus.entity.Student;
import com.nucleus.entity.Subject;
import com.nucleus.pojo.Address;

public class HibernateAssociationDemo {
	public static void main(String[] args) {
		

	Configuration configuration=new Configuration();
	configuration.configure();
	SessionFactory sessionFactory=configuration.buildSessionFactory();
	Session session=sessionFactory.openSession();
	Transaction transaction=session.beginTransaction();
	
	Subject subject=new Subject();
	subject.setSubCode(1001);
	subject.setSubName("English");
	
	Subject subject2=new Subject();
	subject2.setSubCode(1002);
	subject2.setSubName("Maths");
	
	List<Subject> subjects=new ArrayList<>();
	subjects.add(subject);
	subjects.add(subject2);
	
	Student student=new Student();
	//student.setStudentId(1);
	student.setStudentName("aaaab");
	student.setSubjects(subjects);
	
	subject.setStudent(student);
	subject2.setStudent(student);
	
	/*session.persist(subject);	
	session.persist(subject2);*/
	session.persist(student);
	
	
	System.out.println("saved");
	/*Student stud=(Student)session.get(Student.class, 1);
	System.out.println(stud.getStudentId()+" "+stud.getSubject().getSubName());*/

	/*Student student=(Student)session.get(Student.class, 2);
	System.out.println(student.getStudentId()+" "+student.getStudentName());
	*/transaction.commit();
	
	
	
	session.close();
	sessionFactory.close();
	}
}
